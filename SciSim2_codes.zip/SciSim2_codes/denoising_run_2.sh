python VAE_denoising.py --flip 0.7
python VAE_denoising.py --flip 0.8
python VAE_denoising.py --flip 0.9